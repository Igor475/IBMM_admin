<?php 
require_once("../conexao.php");
$membrosSede = 0;
$membrosCadastrados = 0;
$pastoresCadastrados = 0;
$igrejasCadastradas = 0;

$query = $pdo->query("SELECT * FROM igrejas");
$res = $query->fetchAll(PDO::FETCH_ASSOC);
$igrejasCadastradas = @count($res);

$query = $pdo->query("SELECT * FROM pastores");
$res = $query->fetchAll(PDO::FETCH_ASSOC);
$pastoresCadastrados = @count($res);


?>


<div class="container-fluid " >
	<section id="minimal-statistics" style="margin-right:20px">
		<div class="row mb-2">
			<div class="col-12 mt-3 mb-1">
				<h4 class="text-uppercase textocinzaescuro">Estatísticas do Sistema</h4>

			</div>
		</div>




		<div class="row mb-4">

			<div class="col-xl-3 col-sm-6 col-12"> 
				<div class="card">
					<div class="card-content">
						<div class="card-body">
							<div class="row">
								<div class="align-self-center col-3">
									<i class="bi bi-house-door-fill text-success fs-1 float-start"></i>
								</div>
								<div class="col-9 text-end">
									<h3> <span class="text-success"><?php echo @$igrejasCadastradas ?></span></h3>
									<span class="textocinzaescuro">Igrejas Cadastradas</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			


			<div class="col-xl-3 col-sm-6 col-12"> 
				<div class="card">
					<div class="card-content">
						<div class="card-body">
							<div class="row">
								<div class="align-self-center col-3">
									<i class="bi bi-people text-dark fs-1 float-start"></i>
								</div>
								<div class="col-9 text-end">
									<h3> <span class="text-dark"><?php echo @$pastoresCadastrados ?></span></h3>
									<span class="textocinzaescuro">Pastores Cadastrados</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>


			<div class="col-xl-3 col-sm-6 col-12"> 
				<div class="card">
					<div class="card-content">
						<div class="card-body">
							<div class="row">
								<div class="align-self-center col-3">
									<i class="bi bi-person-fill text-primary fs-1 float-start"></i>
								</div>
								<div class="col-9 text-end">
									<h3> <span class="text-primary"><?php echo @$membrosSede ?></span></h3>
									<span class="textocinzaescuro">Membros da Sede</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>


			<div class="col-xl-3 col-sm-6 col-12"> 
				<div class="card">
					<div class="card-content">
						<div class="card-body">
							<div class="row">
								<div class="align-self-center col-3">
									<i class="bi bi-people-fill text-danger fs-1 float-start"></i>
								</div>
								<div class="col-9 text-end">
									<h3> <span class="text-danger"><?php echo @$membrosCadastrados ?></span></h3>
									<span class="textocinzaescuro">Total de Membros</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>





	</section>


	<div class="text-xs font-weight-bold text-secondary text-uppercase mt-4"><small>IGREJAS - SEDE E FILIAIS</small></div>
		<hr> 

		<div class="row" style="margin-right:10px">

			<?php 

			$query = $pdo->query("SELECT * FROM igrejas order by matriz desc, nome asc");
			$res = $query->fetchAll(PDO::FETCH_ASSOC);
			$total_reg = count($res);

			for($i=0; $i < $total_reg; $i++){
				foreach ($res[$i] as $key => $value){} 

					$nome = $res[$i]['nome'];
					//$pastor = $res[$i]['pastor'];
					$imagem = $res[$i]['imagem'];
					$matriz = $res[$i]['matriz'];

					if($matriz == 'Sim'){
						$bordacard = 'bordacardsede';
						$classe = 'text-danger';
					}else{
						$bordacard = 'bordacard';
						$classe = 'text-primary';
					}
				?>
					
					<div class="col-xl-3 col-md-6 col-12 mb-4 linkcard">
						<a href="#">
						<div class="card <?php echo $classe ?> shadow h-100 py-2 <?php echo $bordacard ?>">
							<div class="card-body">
								<div class="row no-gutters align-items-center">
									<div class="col mr-2">
										<div class="text-xs font-weight-bold <?php echo $classe ?> text-uppercase titulocard"><?php echo $nome ?></div>
										<div class="text-xs text-secondary subtitulocard">PASTOR RESPONSÁVEL </div>
									</div>
									<div class="col-auto" align="center">
										<img src="../img/igrejas/<?php echo $imagem ?>" width="50px" height="50px"><br>
										<span class="text-xs totaiscard <?php echo $classe ?>">30 MEMBROS</span>
									</div>
								</div>
							</div>
						</div>
						</a>
					</div>
					

										
			<?php } ?>

		</div>
</div>