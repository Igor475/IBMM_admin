-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 24-Jun-2021 às 01:00
-- Versão do servidor: 10.4.17-MariaDB
-- versão do PHP: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `igreja`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `bispos`
--

CREATE TABLE `bispos` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `foto` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `bispos`
--

INSERT INTO `bispos` (`id`, `nome`, `email`, `cpf`, `telefone`, `endereco`, `foto`) VALUES
(1, 'Pastor Presidente', 'sistemasparaigrejas@gmail.com', '000.000.000-00', '(00)00000-0000', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', '22-06-2021-18-30-33-user.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `config`
--

INSERT INTO `config` (`id`, `nome`, `email`, `telefone`, `endereco`) VALUES
(1, 'Igreja Pentecostal', 'sistemasparaigrejas@gmail.com', '(00) 00000-0000', 'Rua A, Número 150, Bairro XX - Belo Horizonte - MG');

-- --------------------------------------------------------

--
-- Estrutura da tabela `igrejas`
--

CREATE TABLE `igrejas` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(150) DEFAULT NULL,
  `obs` text DEFAULT NULL,
  `imagem` varchar(150) DEFAULT NULL,
  `matriz` varchar(5) NOT NULL,
  `data_cad` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `igrejas`
--

INSERT INTO `igrejas` (`id`, `nome`, `telefone`, `endereco`, `obs`, `imagem`, `matriz`, `data_cad`) VALUES
(1, 'Igreja Pentecostal', '(00) 00000-0000', 'Rua A, Número 150, Bairro XX - Belo Horizonte - MG', 'Igreja Matriz Fundada em ...', '23-06-2021-19-50-30-logo3.jpg', 'Sim', '2021-06-23'),
(3, 'Pentecostal Serra Verde', '(56) 55545-8555', 'Rua A, Número 150, Bairro XX - Belo Horizonte - MG', NULL, '23-06-2021-19-50-39-logo2.jpg', 'Não', '2021-06-23'),
(4, 'Pentescoltal Santa Mônica', '(66) 58412-1545', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', NULL, '23-06-2021-19-50-46-logo-2354472_960_720.png', 'Não', '2021-06-23');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pastores`
--

CREATE TABLE `pastores` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `data_cad` date DEFAULT NULL,
  `data_nasc` date DEFAULT NULL,
  `igreja` int(11) NOT NULL,
  `obs` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pastores`
--

INSERT INTO `pastores` (`id`, `nome`, `email`, `cpf`, `telefone`, `endereco`, `foto`, `data_cad`, `data_nasc`, `igreja`, `obs`) VALUES
(1, 'Marco Tulio', 'marco@hotmail.com', '595.872.541-51', '(65) 62845-1515', 'Rua C', 'sem-foto.jpg', '2021-06-22', '2021-06-22', 0, ''),
(2, 'Pastor Teste', 'pastor@hotmail.com', '314.545.484-55', '(85) 84551-4554', 'Rua Almeida Campos 150', '22-06-2021-18-55-27-Homemsemrostoretrato(33).png', '2021-06-22', '2021-06-22', 0, 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),
(5, 'dsdafadsf', 'aasssa@hugocursos.com.br', '454.845.454-54', '(54) 54548-4545', 'Rua C', 'sem-foto.jpg', '2021-06-22', '1995-06-22', 4, 'O pastor solicitou .....\r\nFoi Definido que ...'),
(6, 'fadfaf', 'aassaaa@hugocursos.com.br', '445.845.555-55', '(55) 64555-5555', 'Rua A', 'sem-foto.jpg', '2021-06-23', '2021-06-23', 3, NULL),
(7, 'dfafsdfad', 'asssssaaaa@hugocursos.com.br', '458.415.151-54', '(45) 45455-5556', '', 'sem-foto.jpg', '2021-06-23', '2021-06-23', 1, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `secretarios`
--

CREATE TABLE `secretarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `secretarios`
--

INSERT INTO `secretarios` (`id`, `nome`, `email`, `cpf`, `telefone`, `endereco`, `foto`, `igreja`) VALUES
(2, 'Secretário Teste', 'secretario@hotmail.com', '258.105.184-54', '(54) 12102-5545', 'Rua Almeida Campos 150', '23-06-2021-13-18-58-01.jpg', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tesoureiros`
--

CREATE TABLE `tesoureiros` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tesoureiros`
--

INSERT INTO `tesoureiros` (`id`, `nome`, `email`, `cpf`, `telefone`, `endereco`, `foto`, `igreja`) VALUES
(2, 'Tesoureiro Teste', 'tesoureiro@hotmail.com', '595.252.024-12', '(25) 48451-5155', 'Rua Almeida Campos 150', '23-06-2021-13-18-26-02.jpg', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL,
  `nivel` varchar(50) NOT NULL,
  `id_pessoa` int(11) NOT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `cpf`, `email`, `senha`, `nivel`, `id_pessoa`, `foto`, `igreja`) VALUES
(6, 'Pastor Presidente', '000.000.000-00', 'sistemasparaigrejas@gmail.com', '123', 'bispo', 1, '22-06-2021-18-30-33-user.jpg', 0),
(10, 'Marco Tulio', '595.872.541-51', 'marco@hotmail.com', '123', 'pastor', 1, 'sem-foto.jpg', 0),
(11, 'Pastor Teste', '314.545.484-55', 'pastor@hotmail.com', '123', 'pastor', 2, '22-06-2021-18-55-27-Homemsemrostoretrato(33).png', 0),
(14, 'dsdafadsf', '454.845.454-54', 'aasssa@hugocursos.com.br', '123', 'pastor', 5, 'sem-foto.jpg', 4),
(18, 'Tesoureiro Teste', '595.252.024-12', 'tesoureiro@hotmail.com', '123', 'tesoureiro', 2, '23-06-2021-13-18-26-02.jpg', 1),
(19, 'Secretário Teste', '258.105.184-54', 'secretario@hotmail.com', '123', 'secretario', 2, '23-06-2021-13-18-58-01.jpg', 1),
(20, 'fadfaf', '445.845.555-55', 'aassaaa@hugocursos.com.br', '123', 'pastor', 6, 'sem-foto.jpg', 3),
(21, 'dfafsdfad', '458.415.151-54', 'asssssaaaa@hugocursos.com.br', '123', 'pastor', 7, 'sem-foto.jpg', 1);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `bispos`
--
ALTER TABLE `bispos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `igrejas`
--
ALTER TABLE `igrejas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `pastores`
--
ALTER TABLE `pastores`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `secretarios`
--
ALTER TABLE `secretarios`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tesoureiros`
--
ALTER TABLE `tesoureiros`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `bispos`
--
ALTER TABLE `bispos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `igrejas`
--
ALTER TABLE `igrejas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `pastores`
--
ALTER TABLE `pastores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `secretarios`
--
ALTER TABLE `secretarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `tesoureiros`
--
ALTER TABLE `tesoureiros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
