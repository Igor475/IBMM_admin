-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 06-Jul-2021 às 17:12
-- Versão do servidor: 10.4.17-MariaDB
-- versão do PHP: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `igreja`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `anexos`
--

CREATE TABLE `anexos` (
  `id` int(11) NOT NULL,
  `nome` varchar(70) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `arquivo` varchar(150) NOT NULL,
  `data` date NOT NULL,
  `usuario` int(11) NOT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `anexos`
--

INSERT INTO `anexos` (`id`, `nome`, `descricao`, `arquivo`, `data`, `usuario`, `igreja`) VALUES
(1, 'Prestação de Contas', 'Dizimos, Ofertas, Vendas etc', '05-07-2021-13-07-22-pedido.rar', '2021-07-05', 6, 3),
(2, 'Relatório de Membros', 'Relatório demonstrativo...', '05-07-2021-13-27-40-pedido.pdf', '2021-07-05', 27, 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `bispos`
--

CREATE TABLE `bispos` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `foto` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `bispos`
--

INSERT INTO `bispos` (`id`, `nome`, `email`, `cpf`, `telefone`, `endereco`, `foto`) VALUES
(1, 'Pastor Presidente', 'sistemasparaigrejas@gmail.com', '000.000.000-00', '(00)00000-0000', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', '22-06-2021-18-30-33-user.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cargos`
--

CREATE TABLE `cargos` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `cargos`
--

INSERT INTO `cargos` (`id`, `nome`) VALUES
(1, 'Membro'),
(2, 'Diácono'),
(3, 'Evangelista'),
(4, 'Missionário');

-- --------------------------------------------------------

--
-- Estrutura da tabela `celulas`
--

CREATE TABLE `celulas` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `dias` varchar(150) NOT NULL,
  `hora` varchar(100) NOT NULL,
  `local` varchar(100) DEFAULT NULL,
  `pastor` int(11) NOT NULL,
  `coordenador` int(11) NOT NULL,
  `lider1` int(11) NOT NULL,
  `lider2` int(11) NOT NULL,
  `obs` text DEFAULT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `celulas`
--

INSERT INTO `celulas` (`id`, `nome`, `dias`, `hora`, `local`, `pastor`, `coordenador`, `lider1`, `lider2`, `obs`, `igreja`) VALUES
(2, 'Célula das Irmãs', 'Sexta Feira', 'Das 19:00 as 20:00', 'Rua X Número 120 Bairro Candelária', 2, 4, 8, 0, NULL, 3),
(3, 'Célula Quarta Feira', 'Quarta Feira', 'Das 20:00 as 20:45', 'Rua Y', 8, 0, 8, 4, 'Essa célula está por enquanto suspensa..', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `celulas_membros`
--

CREATE TABLE `celulas_membros` (
  `id` int(11) NOT NULL,
  `membro` int(11) NOT NULL,
  `celula` int(11) NOT NULL,
  `data` date NOT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `celulas_membros`
--

INSERT INTO `celulas_membros` (`id`, `membro`, `celula`, `data`, `igreja`) VALUES
(12, 8, 2, '2021-07-06', 3),
(13, 4, 2, '2021-07-06', 3),
(16, 8, 3, '2021-07-06', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(150) NOT NULL,
  `qtd_tarefas` int(11) NOT NULL,
  `limitar_tesoureiro` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `config`
--

INSERT INTO `config` (`id`, `nome`, `email`, `telefone`, `endereco`, `qtd_tarefas`, `limitar_tesoureiro`) VALUES
(1, 'Igreja Pentecostal', 'sistemasparaigrejas@gmail.com', '(00) 00000-0000', 'Rua A, Número 150, Bairro XX - Belo Horizonte - MG', 20, 'Sim');

-- --------------------------------------------------------

--
-- Estrutura da tabela `dizimos`
--

CREATE TABLE `dizimos` (
  `id` int(11) NOT NULL,
  `membro` int(11) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `data` date NOT NULL,
  `usuario` int(11) NOT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `dizimos`
--

INSERT INTO `dizimos` (`id`, `membro`, `valor`, `data`, `usuario`, `igreja`) VALUES
(10, 1, '380.00', '2021-06-29', 26, 3),
(11, 0, '360.00', '2021-06-27', 26, 3),
(12, 4, '460.00', '2021-06-29', 26, 3),
(14, 1, '1500.00', '2021-06-30', 27, 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `doacoes`
--

CREATE TABLE `doacoes` (
  `id` int(11) NOT NULL,
  `membro` int(11) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `data` date NOT NULL,
  `usuario` int(11) NOT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `doacoes`
--

INSERT INTO `doacoes` (`id`, `membro`, `valor`, `data`, `usuario`, `igreja`) VALUES
(1, 0, '1500.00', '2021-06-29', 6, 3),
(2, 2, '1200.00', '2021-06-29', 6, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `documentos`
--

CREATE TABLE `documentos` (
  `id` int(11) NOT NULL,
  `nome` varchar(70) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `arquivo` varchar(150) NOT NULL,
  `data` date NOT NULL,
  `usuario` int(11) NOT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `documentos`
--

INSERT INTO `documentos` (`id`, `nome`, `descricao`, `arquivo`, `data`, `usuario`, `igreja`) VALUES
(2, 'Contrato de Locação', 'Contrato de Locação feito em Março de 2021', '05-07-2021-11-17-09-pedido.rar', '2021-07-05', 6, 3),
(3, 'Contrato de Mesas', 'Mesas alugadas para evento data dia 20/03/2020', '05-07-2021-11-26-17-pedido.pdf', '2021-07-05', 6, 3),
(5, 'Documento XY', 'Descricao do Documento x....', '05-07-2021-11-45-54-logo-igreja2.png', '2021-07-03', 6, 3),
(6, 'Contrato X', 'Contrato ...', '05-07-2021-11-52-26-arquivo-teste.docx', '2021-07-05', 6, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornecedores`
--

CREATE TABLE `fornecedores` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `produto` varchar(100) DEFAULT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `fornecedores`
--

INSERT INTO `fornecedores` (`id`, `nome`, `telefone`, `email`, `endereco`, `produto`, `igreja`) VALUES
(1, 'Raphael Silva', '(15) 10545-4545', 'rafael@hotmail.com', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', 'Cadeiras e Bancos', 3),
(2, 'Fabricio Silva', '(54) 85445-4555', 'fabricio@hotmail.com', '', 'Materiais de Limpeza', 3),
(3, 'Matheus Silva', '(32) 15454-5455', 'mateus@hotmail.com', '', 'Serviço de Pedreiro', 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `frequencias`
--

CREATE TABLE `frequencias` (
  `id` int(11) NOT NULL,
  `frequencia` varchar(35) NOT NULL,
  `dias` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `frequencias`
--

INSERT INTO `frequencias` (`id`, `frequencia`, `dias`) VALUES
(1, 'Uma Vez', 0),
(2, 'Diária', 1),
(3, 'Semanal', 7),
(4, 'Mensal', 30),
(5, 'Semestral', 180),
(6, 'Anual', 365);

-- --------------------------------------------------------

--
-- Estrutura da tabela `grupos`
--

CREATE TABLE `grupos` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `dias` varchar(75) NOT NULL,
  `hora` varchar(50) NOT NULL,
  `local` varchar(100) DEFAULT NULL,
  `pastor` int(11) NOT NULL,
  `tesoureiro` int(11) NOT NULL,
  `secretario` int(11) NOT NULL,
  `regente` int(11) NOT NULL,
  `lider1` int(11) NOT NULL,
  `lider2` int(11) NOT NULL,
  `obs` text DEFAULT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `grupos`
--

INSERT INTO `grupos` (`id`, `nome`, `dias`, `hora`, `local`, `pastor`, `tesoureiro`, `secretario`, `regente`, `lider1`, `lider2`, `obs`, `igreja`) VALUES
(1, 'Grupo de Oração', 'Quinta Feira', 'Das 20:00 as 20:45', 'Rua X Número 120 Bairro Candelária', 8, 8, 3, 8, 8, 4, 'fsfeferwaeraw', 3),
(2, 'Grupo de Louvor', 'Quinta Feira', 'Das 19:00 as 20:00', 'Rua X Número 120 Bairro Candelária', 8, 0, 0, 0, 8, 0, NULL, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `grupos_membros`
--

CREATE TABLE `grupos_membros` (
  `id` int(11) NOT NULL,
  `membro` int(11) NOT NULL,
  `grupo` int(11) NOT NULL,
  `data` date NOT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `grupos_membros`
--

INSERT INTO `grupos_membros` (`id`, `membro`, `grupo`, `data`, `igreja`) VALUES
(1, 8, 1, '2021-07-06', 3),
(3, 8, 2, '2021-07-06', 3),
(4, 4, 1, '2021-07-06', 3),
(5, 4, 2, '2021-07-06', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `igrejas`
--

CREATE TABLE `igrejas` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(150) DEFAULT NULL,
  `obs` text DEFAULT NULL,
  `imagem` varchar(150) DEFAULT NULL,
  `matriz` varchar(5) NOT NULL,
  `data_cad` date NOT NULL,
  `pastor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `igrejas`
--

INSERT INTO `igrejas` (`id`, `nome`, `telefone`, `endereco`, `obs`, `imagem`, `matriz`, `data_cad`, `pastor`) VALUES
(1, 'Igreja Pentecostal', '(00) 00000-0000', 'Rua A, Número 150, Bairro XX - Belo Horizonte - MG', 'Igreja Matriz Fundada em ...', '28-06-2021-20-06-14-logo-icone.png', 'Sim', '2021-06-23', 1),
(3, 'Pentecostal Serra Verde', '(56) 55545-8555', 'Rua A, Número 150, Bairro XX - Belo Horizonte - MG', NULL, '28-06-2021-20-02-47-logo-igreja2.png', 'Não', '2021-06-23', 3),
(4, 'Pentescoltal Santa Mônica', '(66) 58412-1549', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', NULL, '28-06-2021-20-02-37-logo-igreja.png', 'Não', '2021-06-23', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `membros`
--

CREATE TABLE `membros` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `foto` varchar(150) NOT NULL,
  `data_cad` date NOT NULL,
  `data_nasc` date NOT NULL,
  `igreja` int(11) NOT NULL,
  `obs` text DEFAULT NULL,
  `data_batismo` date DEFAULT NULL,
  `cargo` varchar(50) NOT NULL,
  `ativo` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `membros`
--

INSERT INTO `membros` (`id`, `nome`, `email`, `cpf`, `telefone`, `endereco`, `foto`, `data_cad`, `data_nasc`, `igreja`, `obs`, `data_batismo`, `cargo`, `ativo`) VALUES
(1, 'Fábio Silva', 'fabio@hotmail.com', '584.512.545-15', '(65) 23511-4545', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', '28-06-2021-14-39-48-01.jpg', '2021-06-28', '1992-06-08', 4, 'Membro ....', '2012-04-15', '4', 'Sim'),
(2, 'Marta Silva', 'marta@hotmail.com', '545.484.545-41', '(25) 85205-4546', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', 'sem-foto.jpg', '2021-06-28', '1998-06-14', 4, NULL, '0000-00-00', '1', 'Sim'),
(4, 'Pablo Campos', 'pablo@hotmail.com', '554.415.454-55', '(54) 51545-4545', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', 'sem-foto.jpg', '2021-06-28', '2021-06-09', 3, NULL, '2021-06-08', '2', 'Sim'),
(5, 'Paola Silva', 'paola@hotmail.com', '687.845.154-54', '(05) 51548-4545', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', 'sem-foto.jpg', '2021-06-28', '2021-06-09', 1, NULL, '2021-06-02', '1', 'Sim'),
(6, 'Marcela Silva', 'marcela@hotmail.com', '584.154.558-74', '(65) 21451-5454', 'Rua A, Número 150, Bairro XX - Belo Horizonte - MG', 'sem-foto.jpg', '2021-06-28', '1990-06-01', 1, NULL, '0000-00-00', '1', 'Sim'),
(7, 'Pablo Silva', 'pablos@hotmail.com', '484.154.545-55', '(21) 15154-5454', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', '28-06-2021-14-56-14-01.jpg', '2021-06-28', '1995-06-01', 1, NULL, '0000-00-00', '3', 'Sim'),
(8, 'Marcelo Santos', 'marcela@hugocursos.com.br', '455.455.555', '(87) 45445-4544', 'Rua A, Número 150, Bairro XX - Belo Horizonte - MG', '28-06-2021-17-30-12-02.jpg', '2021-06-28', '2021-06-02', 3, NULL, '0000-00-00', '1', 'Sim'),
(9, 'Fatima', 'fatima@hotmail.com', '694.841.545-54', '(64) 55754-5454', 'Rua Almeida Campos 150', 'sem-foto.jpg', '2021-06-29', '2000-06-01', 4, NULL, '0000-00-00', '1', 'Sim'),
(10, 'Marcelo', 'marcelo@hotmail.com', '648.454.545-55', '(87) 85444-5454', 'Rua A, Número 150, Bairro XX - Belo Horizonte - MG', 'sem-foto.jpg', '2021-06-29', '1999-06-01', 4, NULL, '0000-00-00', '1', 'Sim');

-- --------------------------------------------------------

--
-- Estrutura da tabela `movimentacoes`
--

CREATE TABLE `movimentacoes` (
  `id` int(11) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `movimento` varchar(25) NOT NULL,
  `descricao` varchar(50) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `data` date NOT NULL,
  `usuario` int(11) NOT NULL,
  `id_mov` int(11) NOT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `movimentacoes`
--

INSERT INTO `movimentacoes` (`id`, `tipo`, `movimento`, `descricao`, `valor`, `data`, `usuario`, `id_mov`, `igreja`) VALUES
(5, 'Saída', 'Conta à Pagar', 'Produtos de Limpeza', '680.00', '2021-06-29', 26, 3, 3),
(6, 'Saída', 'Conta à Pagar', 'Conta diaria', '50.00', '2021-06-29', 26, 15, 3),
(7, 'Saída', 'Conta à Pagar', 'Conta diaria', '50.00', '2021-06-29', 26, 16, 3),
(8, 'Saída', 'Conta à Pagar', 'Conta teste 2', '350.00', '2021-06-29', 26, 18, 3),
(15, 'Entrada', 'Dízimo', 'Fábio Silva', '380.00', '2021-06-29', 26, 10, 3),
(16, 'Entrada', 'Dízimo', 'Membro Não Informado', '360.00', '2021-06-27', 26, 11, 3),
(17, 'Entrada', 'Dízimo', 'Pablo Campos', '460.00', '2021-06-29', 26, 12, 3),
(22, 'Entrada', 'Oferta', 'Paola Silva', '600.00', '2021-06-29', 26, 4, 3),
(23, 'Entrada', 'Oferta', 'Membro Não Informado', '50.00', '2021-06-29', 26, 5, 3),
(24, 'Entrada', 'Oferta', 'Fábio Silva', '199.00', '2021-06-29', 26, 6, 3),
(27, 'Entrada', 'Oferta', 'Membro Não Informado', '240.00', '2021-06-29', 33, 9, 3),
(29, 'Entrada', 'Doação', 'Membro Não Informado', '1500.00', '2021-06-29', 6, 1, 3),
(30, 'Entrada', 'Doação', 'Marta Silva', '1200.00', '2021-06-29', 6, 2, 3),
(32, 'Entrada', 'Venda', 'Vendas da Cantina', '1350.00', '2021-06-29', 6, 1, 3),
(33, 'Entrada', 'Venda', 'Vendas da Cantina', '950.00', '2021-06-28', 6, 2, 3),
(34, 'Entrada', 'Venda', 'Conta de Luz', '550.00', '2021-06-29', 6, 0, 3),
(35, 'Entrada', 'Venda', 'Conta de Luz', '550.00', '2021-06-29', 6, 0, 3),
(36, 'Entrada', 'Venda', 'Cantina', '55.00', '2021-06-29', 6, 0, 3),
(37, 'Saída', 'Conta à Pagar', 'Produtos de Limpeza', '500.00', '2021-06-30', 6, 22, 3),
(38, 'Saída', 'Conta à Pagar', 'Aluguel', '1600.00', '2021-06-30', 6, 11, 3),
(40, 'Entrada', 'Venda', 'Vendas da Cantina', '1600.00', '2021-06-30', 6, 4, 3),
(41, 'Entrada', 'Dízimo', 'Fábio Silva', '1500.00', '2021-06-30', 27, 14, 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `ofertas`
--

CREATE TABLE `ofertas` (
  `id` int(11) NOT NULL,
  `membro` varchar(50) DEFAULT NULL,
  `valor` decimal(8,2) NOT NULL,
  `data` date NOT NULL,
  `usuario` int(11) NOT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `ofertas`
--

INSERT INTO `ofertas` (`id`, `membro`, `valor`, `data`, `usuario`, `igreja`) VALUES
(4, '5', '600.00', '2021-06-29', 26, 3),
(5, '0', '50.00', '2021-06-29', 26, 3),
(6, '1', '199.00', '2021-06-29', 26, 3),
(9, '0', '240.00', '2021-06-29', 33, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagar`
--

CREATE TABLE `pagar` (
  `id` int(11) NOT NULL,
  `descricao` varchar(50) DEFAULT NULL,
  `fornecedor` int(11) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `data` date NOT NULL,
  `vencimento` date NOT NULL,
  `usuario_cad` int(11) NOT NULL,
  `usuario_baixa` int(11) NOT NULL,
  `data_baixa` date DEFAULT NULL,
  `frequencia` int(11) NOT NULL,
  `pago` varchar(5) NOT NULL,
  `arquivo` varchar(150) DEFAULT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pagar`
--

INSERT INTO `pagar` (`id`, `descricao`, `fornecedor`, `valor`, `data`, `vencimento`, `usuario_cad`, `usuario_baixa`, `data_baixa`, `frequencia`, `pago`, `arquivo`, `igreja`) VALUES
(1, 'Conta de Luz', 0, '550.00', '2021-06-29', '2021-06-29', 6, 6, '2021-06-29', 0, 'Sim', 'sem-foto.jpg', 3),
(2, 'Compra de Cadeira', 1, '890.00', '2021-06-29', '2021-06-30', 6, 26, '2021-06-29', 0, 'Sim', '29-06-2021-13-20-41-pedido.pdf', 3),
(3, 'Produtos de Limpeza', 2, '680.00', '2021-06-29', '2021-07-01', 6, 26, '2021-06-29', 0, 'Sim', '29-06-2021-13-21-28-pedido.rar', 3),
(4, 'Conta de Água', 0, '980.00', '2021-06-29', '2021-06-28', 6, 0, NULL, 0, 'Não', '29-06-2021-13-32-34-conta3.jpg', 3),
(5, 'Conta Vencida', 1, '200.00', '2021-06-29', '2021-06-27', 6, 6, '2021-06-29', 7, 'Sim', '29-06-2021-13-39-40-conta3.jpg', 3),
(10, 'Aluguel', 3, '1600.00', '2021-06-29', '2021-06-24', 6, 26, '2021-06-29', 30, 'Sim', 'sem-foto.jpg', 3),
(11, 'Aluguel', 3, '1600.00', '2021-06-29', '2021-07-24', 26, 6, '2021-06-30', 30, 'Sim', 'sem-foto.jpg', 3),
(12, 'Limpeza da Igreja', 2, '250.00', '2021-06-29', '2021-06-29', 26, 26, '2021-06-29', 7, 'Sim', 'sem-foto.jpg', 3),
(13, 'Limpeza da Igreja', 2, '250.00', '2021-06-29', '2021-07-06', 26, 0, NULL, 7, 'Não', 'sem-foto.jpg', 3),
(14, 'Conta diaria', 0, '50.00', '2021-06-29', '2021-06-29', 26, 26, '2021-06-29', 1, 'Sim', 'sem-foto.jpg', 3),
(15, 'Conta diaria', 0, '50.00', '2021-06-29', '2021-06-30', 26, 26, '2021-06-29', 1, 'Sim', 'sem-foto.jpg', 3),
(16, 'Conta diaria', 0, '50.00', '2021-06-29', '2021-07-01', 26, 26, '2021-06-29', 1, 'Sim', 'sem-foto.jpg', 3),
(17, 'Conta diaria', 0, '50.00', '2021-06-29', '2021-07-02', 26, 0, NULL, 1, 'Não', 'sem-foto.jpg', 3),
(18, 'Conta teste 2', 1, '350.00', '2021-06-29', '2021-06-29', 26, 26, '2021-06-29', 0, 'Sim', 'sem-foto.jpg', 3),
(19, 'Compra de Microfone', 1, '360.00', '2021-06-29', '2021-06-29', 6, 0, NULL, 0, 'Não', '05-07-2021-11-46-22-logo-igreja3.png', 3),
(20, 'Telefone', 0, '690.00', '2021-06-30', '2021-06-30', 33, 0, NULL, 0, 'Não', '30-06-2021-09-59-57-pedido.pdf', 3),
(21, 'Compra de Fios', 3, '540.00', '2021-06-30', '2021-06-30', 33, 0, NULL, 0, 'Não', 'sem-foto.jpg', 3),
(22, 'Produtos de Limpeza', 1, '500.00', '2021-06-30', '2021-07-02', 6, 6, '2021-06-30', 0, 'Sim', '30-06-2021-10-34-56-pedido.rar', 3),
(23, 'Aluguel', 3, '1600.00', '2021-06-30', '2021-08-24', 6, 0, NULL, 30, 'Não', 'sem-foto.jpg', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pastores`
--

CREATE TABLE `pastores` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `data_cad` date DEFAULT NULL,
  `data_nasc` date DEFAULT NULL,
  `igreja` int(11) NOT NULL,
  `obs` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pastores`
--

INSERT INTO `pastores` (`id`, `nome`, `email`, `cpf`, `telefone`, `endereco`, `foto`, `data_cad`, `data_nasc`, `igreja`, `obs`) VALUES
(1, 'Super Administrador', 'sistemasparaigrejas@gmail.com', '000.000.000-00', '(00)00000-0000', NULL, 'sem-foto.jpg', '2021-06-28', '2021-06-28', 1, NULL),
(2, 'Marcos Santos', 'marcos@hotmail.com', '326.303.032-32', '(36) 23021-2122', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', '28-06-2021-11-31-08-hugo-profile.jpeg', '2021-06-28', '1990-06-03', 3, NULL),
(3, 'Pastor Marcio', 'pastor@hotmail.com', '587.855.555-55', '(52) 12021-1555', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', '28-06-2021-11-31-49-02.jpg', '2021-06-28', '1980-06-01', 4, NULL),
(8, 'Antonio Silva', 'antonio@hotmail.com', '484.144.444-5', '(58) 10215-8451', 'Rua A, Número 150, Bairro XX - Belo Horizonte - MG', 'sem-foto.jpg', '2021-06-28', '1960-06-02', 3, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `patrimonios`
--

CREATE TABLE `patrimonios` (
  `id` int(11) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `valor` decimal(8,2) NOT NULL,
  `foto` varchar(150) NOT NULL,
  `usuario_cad` int(11) NOT NULL,
  `data_cad` date NOT NULL,
  `igreja_cad` int(11) NOT NULL,
  `igreja_item` int(11) NOT NULL,
  `usuario_emprestou` int(11) NOT NULL,
  `data_emprestimo` date DEFAULT NULL,
  `ativo` varchar(5) NOT NULL,
  `obs` text DEFAULT NULL,
  `entrada` varchar(15) NOT NULL,
  `doador` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `patrimonios`
--

INSERT INTO `patrimonios` (`id`, `codigo`, `nome`, `descricao`, `valor`, `foto`, `usuario_cad`, `data_cad`, `igreja_cad`, `igreja_item`, `usuario_emprestou`, `data_emprestimo`, `ativo`, `obs`, `entrada`, `doador`) VALUES
(2, '01234', 'Microfone X573', 'Microfone Preto com cabo ...', '380.00', '05-07-2021-15-03-59-microfone.jpg', 6, '2021-07-05', 4, 4, 0, NULL, 'Não', 'Este microfone deu defeito e parou de funcionar na data x.', 'Compra', ''),
(4, '545', 'Cadeira Branca', 'Cadeira de Festa Branca', '0.00', '05-07-2021-15-16-27-cadeira.jpg', 6, '2021-07-05', 4, 3, 6, '2021-07-05', 'Sim', 'Cadeira doada por um membro, ela está em ótimo estado, estamos utilizando em nossa igreja.', 'Doação', 'Marcos Silva (Membro)'),
(5, '0145', 'Caixa de Som', 'Caixa de Som amperagem ...', '890.00', '05-07-2021-15-26-48-caixa-som.jpg', 6, '2021-07-05', 4, 4, 26, '2021-07-05', 'Sim', NULL, 'Compra', ''),
(6, '08412', 'Microfone X8751', 'Microfone Prata...', '650.00', '05-07-2021-18-17-38-microfone.jpg', 26, '2021-07-05', 3, 3, 6, '2021-07-06', 'Sim', 'aaaaaaaaaaaaaaaaaaa', 'Compra', ''),
(7, '18746', 'Cadeira para Festa', 'Cadeira para Festa', '65.00', '05-07-2021-18-18-25-cadeira.jpg', 6, '2021-07-05', 3, 4, 26, '2021-07-05', 'Sim', 'Cadeira comprada para complementar as cadeiras de festas da igreja, esta cadeira está ....', 'Compra', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `receber`
--

CREATE TABLE `receber` (
  `id` int(11) NOT NULL,
  `descricao` varchar(50) DEFAULT NULL,
  `membro` int(11) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `data` date NOT NULL,
  `vencimento` date NOT NULL,
  `usuario_cad` int(11) NOT NULL,
  `usuario_baixa` int(11) NOT NULL,
  `data_baixa` date DEFAULT NULL,
  `pago` varchar(5) NOT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `receber`
--

INSERT INTO `receber` (`id`, `descricao`, `membro`, `valor`, `data`, `vencimento`, `usuario_cad`, `usuario_baixa`, `data_baixa`, `pago`, `igreja`) VALUES
(1, 'Cantina', 2, '55.00', '2021-06-29', '2021-06-30', 6, 6, '2021-06-29', 'Sim', 3),
(2, 'Cantina', 5, '30.55', '2021-06-29', '2021-06-27', 6, 0, NULL, 'Não', 3),
(4, 'Cantina', 1, '65.00', '2021-06-29', '2021-06-29', 6, 0, NULL, 'Não', 3),
(5, 'Cantina', 5, '85.00', '2021-06-30', '2021-06-30', 33, 0, NULL, 'Não', 3),
(6, 'Cantina', 5, '65.00', '2021-06-30', '2021-07-07', 6, 0, NULL, 'Não', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `secretarios`
--

CREATE TABLE `secretarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `secretarios`
--

INSERT INTO `secretarios` (`id`, `nome`, `email`, `cpf`, `telefone`, `endereco`, `foto`, `igreja`) VALUES
(2, 'Secretário Teste', 'secretario@hotmail.com', '258.105.184-54', '(54) 12102-5545', 'Rua Almeida Campos 150', '23-06-2021-13-18-58-01.jpg', 1),
(3, 'Secretário Teste', 'secretarioteste@hotmail.com', '545.254.512-12', '(82) 04545-455', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', '28-06-2021-13-59-07-hugo-profile.jpeg', 3),
(4, 'Secretario 2', 'sec@hotmail.com', '365.925.451-20', '(64) 51545-4545', 'Rua A, Número 150, Bairro XX - Belo Horizonte - MG', 'sem-foto.jpg', 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tarefas`
--

CREATE TABLE `tarefas` (
  `id` int(11) NOT NULL,
  `titulo` varchar(25) NOT NULL,
  `descricao` varchar(50) DEFAULT NULL,
  `hora` time NOT NULL,
  `data` date NOT NULL,
  `igreja` int(11) NOT NULL,
  `status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tarefas`
--

INSERT INTO `tarefas` (`id`, `titulo`, `descricao`, `hora`, `data`, `igreja`, `status`) VALUES
(2, 'Visita Membro', 'Paula Dos Santos fdsafd afdsaf fad affadf adfsafds', '10:40:00', '2021-06-28', 3, 'Agendada'),
(3, 'Limpeza da Igreja', 'Paloma Silva', '13:00:00', '2021-06-28', 3, 'Agendada'),
(4, 'Contabilidade', 'Controle Financeiro', '09:00:00', '2021-06-28', 3, 'Concluída'),
(5, 'Visitar Membro', 'Marcos Souza', '10:10:00', '2021-06-27', 3, 'Concluída'),
(6, 'Visitar Membro', 'Diacono Santos', '20:30:00', '2021-06-28', 3, 'Agendada'),
(8, 'Visitar Membro', 'Paloma Santos', '12:30:00', '2021-06-29', 4, 'Agendada'),
(9, 'Regulagem de Som', 'Regular os aparelhos de som', '12:00:00', '2021-06-29', 3, 'Agendada'),
(10, 'Visitar Membro', 'Thiago Silva', '15:30:00', '2021-06-29', 3, 'Agendada');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tesoureiros`
--

CREATE TABLE `tesoureiros` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tesoureiros`
--

INSERT INTO `tesoureiros` (`id`, `nome`, `email`, `cpf`, `telefone`, `endereco`, `foto`, `igreja`) VALUES
(2, 'Tesoureiro Teste', 'tesoureiro@hotmail.com', '595.252.024-12', '(25) 48451-5155', 'Rua Almeida Campos 150', '23-06-2021-13-18-26-02.jpg', 1),
(3, 'aafsfdfsa', 'aasssaaa@hugocursos.com.br', '484.521.562-22', '(02) 54554-8555', 'adfsa', 'sem-foto.jpg', 1),
(4, 'fsafa', '45a@hotmail.com', '454.545.455-5', '(14) 54545-5', '545', 'sem-foto.jpg', 1),
(5, 'fsafa', '45sa@hotmail.com', '454.545.455-54', '(14) 54545-5', '545', 'sem-foto.jpg', 1),
(6, 'asfasf', 'assssassaaa@hugocursos.com.br', '548.784.515-4', '(54) 54545-545', '', 'sem-foto.jpg', 1),
(7, 'Rodrigo Silva', 'rodrigo@hotmail.com', '685.151.121-22', '(58) 78451-4554', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', '28-06-2021-13-54-41-hugo-profile.jpeg', 4),
(8, 'Hugo Freitas', 'hugo@hotmail.com', '451.258.451-22', '(56) 78411-2121', 'Rua Almeida Campos 150 Bairro Serra Verde - Belo Horizonte - MG', '28-06-2021-13-57-44-hugo-profile.jpeg', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL,
  `nivel` varchar(50) NOT NULL,
  `id_pessoa` int(11) NOT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `cpf`, `email`, `senha`, `nivel`, `id_pessoa`, `foto`, `igreja`) VALUES
(6, 'Pastor Presidente', '000.000.000-00', 'sistemasparaigrejas@gmail.com', '123', 'bispo', 1, '22-06-2021-18-30-33-user.jpg', 0),
(18, 'Tesoureiro Teste', '595.252.024-12', 'tesoureiro@hotmail.com', '123', 'tesoureiro', 2, '23-06-2021-13-18-26-02.jpg', 1),
(19, 'Secretário Teste', '258.105.184-54', 'secretario@hotmail.com', '123', 'secretario', 2, '23-06-2021-13-18-58-01.jpg', 1),
(22, 'aafsfdfsa', '484.521.562-22', 'aasssaaa@hugocursos.com.br', '123', 'tesoureiro', 3, 'sem-foto.jpg', 1),
(23, 'fsafa', '454.545.455-5', '45a@hotmail.com', '123', 'tesoureiro', 4, 'sem-foto.jpg', 1),
(24, 'fsafa', '454.545.455-54', '45sa@hotmail.com', '123', 'tesoureiro', 5, 'sem-foto.jpg', 1),
(25, 'asfasf', '548.784.515-4', 'assssassaaa@hugocursos.com.br', '123', 'tesoureiro', 6, 'sem-foto.jpg', 1),
(26, 'Marcos Santos', '326.303.032-32', 'marcos@hotmail.com', '123', 'pastor', 2, '28-06-2021-11-31-08-hugo-profile.jpeg', 3),
(27, 'Pastor Marcio', '587.855.555-55', 'pastor@hotmail.com', '123', 'pastor', 3, '28-06-2021-11-31-49-02.jpg', 4),
(32, 'Rodrigo Silva', '685.151.121-22', 'rodrigo@hotmail.com', '123', 'tesoureiro', 7, '28-06-2021-13-54-41-hugo-profile.jpeg', 4),
(33, 'Hugo Freitas', '451.258.451-22', 'hugo@hotmail.com', '123', 'tesoureiro', 8, '28-06-2021-13-57-44-hugo-profile.jpeg', 3),
(34, 'Secretário Teste', '545.254.512-12', 'secretarioteste@hotmail.com', '123', 'secretario', 3, '28-06-2021-13-59-07-hugo-profile.jpeg', 3),
(35, 'Secretario 2', '365.925.451-20', 'sec@hotmail.com', '123', 'secretario', 4, 'sem-foto.jpg', 4),
(36, 'Antonio Silva', '484.144.444-5', 'antonio@hotmail.com', '123', 'pastor', 8, 'sem-foto.jpg', 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendas`
--

CREATE TABLE `vendas` (
  `id` int(11) NOT NULL,
  `descricao` varchar(100) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `data` date NOT NULL,
  `usuario` int(11) NOT NULL,
  `igreja` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `vendas`
--

INSERT INTO `vendas` (`id`, `descricao`, `valor`, `data`, `usuario`, `igreja`) VALUES
(1, 'Vendas da Cantina', '1350.00', '2021-06-29', 6, 3),
(2, 'Vendas da Cantina', '950.00', '2021-06-28', 6, 3),
(4, 'Vendas da Cantina', '1600.00', '2021-06-30', 6, 3);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `anexos`
--
ALTER TABLE `anexos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `bispos`
--
ALTER TABLE `bispos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `cargos`
--
ALTER TABLE `cargos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `celulas`
--
ALTER TABLE `celulas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `celulas_membros`
--
ALTER TABLE `celulas_membros`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `dizimos`
--
ALTER TABLE `dizimos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `doacoes`
--
ALTER TABLE `doacoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `documentos`
--
ALTER TABLE `documentos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `fornecedores`
--
ALTER TABLE `fornecedores`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `frequencias`
--
ALTER TABLE `frequencias`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `grupos`
--
ALTER TABLE `grupos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `grupos_membros`
--
ALTER TABLE `grupos_membros`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `igrejas`
--
ALTER TABLE `igrejas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `membros`
--
ALTER TABLE `membros`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `movimentacoes`
--
ALTER TABLE `movimentacoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `ofertas`
--
ALTER TABLE `ofertas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `pagar`
--
ALTER TABLE `pagar`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `pastores`
--
ALTER TABLE `pastores`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `patrimonios`
--
ALTER TABLE `patrimonios`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `receber`
--
ALTER TABLE `receber`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `secretarios`
--
ALTER TABLE `secretarios`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tarefas`
--
ALTER TABLE `tarefas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tesoureiros`
--
ALTER TABLE `tesoureiros`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `vendas`
--
ALTER TABLE `vendas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `anexos`
--
ALTER TABLE `anexos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `bispos`
--
ALTER TABLE `bispos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `cargos`
--
ALTER TABLE `cargos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de tabela `celulas`
--
ALTER TABLE `celulas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `celulas_membros`
--
ALTER TABLE `celulas_membros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `dizimos`
--
ALTER TABLE `dizimos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `doacoes`
--
ALTER TABLE `doacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `documentos`
--
ALTER TABLE `documentos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `fornecedores`
--
ALTER TABLE `fornecedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `frequencias`
--
ALTER TABLE `frequencias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `grupos`
--
ALTER TABLE `grupos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `grupos_membros`
--
ALTER TABLE `grupos_membros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `igrejas`
--
ALTER TABLE `igrejas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `membros`
--
ALTER TABLE `membros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `movimentacoes`
--
ALTER TABLE `movimentacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT de tabela `ofertas`
--
ALTER TABLE `ofertas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `pagar`
--
ALTER TABLE `pagar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `pastores`
--
ALTER TABLE `pastores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `patrimonios`
--
ALTER TABLE `patrimonios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `receber`
--
ALTER TABLE `receber`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `secretarios`
--
ALTER TABLE `secretarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tarefas`
--
ALTER TABLE `tarefas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `tesoureiros`
--
ALTER TABLE `tesoureiros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT de tabela `vendas`
--
ALTER TABLE `vendas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
